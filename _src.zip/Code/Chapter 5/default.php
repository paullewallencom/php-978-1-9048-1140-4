<?
include("libs/smarty.class.php");
$smarty = new smarty();
$smarty->display("default.tpl");
?>
