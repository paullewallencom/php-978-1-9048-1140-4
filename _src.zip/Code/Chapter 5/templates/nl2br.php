Following is an example of nl2br
{$sometext|nl2br}