<?php
include_once('libs/Smarty.class.php');
$smarty = new Smarty;

$smarty->display('example_calendar.tpl');
?>
