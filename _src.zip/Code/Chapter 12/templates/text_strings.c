/* gettext1.tpl */
gettext("A message to translate");

