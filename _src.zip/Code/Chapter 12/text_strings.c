/* templates/parameters.tpl */
gettext("Passing Parameters to Translations");

/* templates/parameters.tpl */
gettext("Passing Parameters to Translations");

/* templates/parameters.tpl */
gettext("\n  There are %1 customers waiting for %2 orders.\n  ");

