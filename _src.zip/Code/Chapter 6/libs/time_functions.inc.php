<?php
function smarty_insert_getCurrentTime()
{
    return gmdate('l, j F Y g:i a T');
}
?>
