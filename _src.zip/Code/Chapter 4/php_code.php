<?
include("libs/smarty.class.php");
$smarty = new smarty();
$smarty->display("php_code.tpl")
?>
